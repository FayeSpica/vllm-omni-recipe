import subprocess,json,math,time
from pathlib import Path
r=Path('/bench/boundary128-20261111')
def run(c,tag,requests):
 out=r/tag
 subprocess.run(['/bench/rsi-venv/bin/python',str(r/'mixed_client.py'),'--engine','rsi','--case','/bench/case.json','--out',str(out),'--url','http://127.0.0.1:18364','--concurrency',str(c),'--requests',str(requests),'--warmup','0'],stdout=(r/(tag+'.log')).open('w'),check=True)
 d=json.loads((out/'summary.json').read_text());rows=d['results']
 assert len(rows)==requests and all(x['status']==200 and not x['error'] and .5<x['audio_s']<40.8 for x in rows)
 q=lambda x:sorted(x)[math.ceil(.95*len(x))-1]
 result={'tag':tag,'c':c,'requests':requests,'zero_pass':sum(x['playback_clock']['0']['underruns']==0 for x in rows),'ttfa_p95_ms':q([x['ttfa_s']*1000 for x in rows]),'rtf_p95':q([x['elapsed_s']/x['audio_s'] for x in rows]),'max_gap_s':max(x['playback_clock']['0']['max_gap_s'] for x in rows)}
 with (r/'progress.jsonl').open('a') as f:f.write(json.dumps(result)+'\n')
 print(json.dumps(result),flush=True)
 return result
if __name__=='__main__':
 run(64,'warm1',128);run(64,'warm2',128)
 results=[]
 for c in (1,4,6,7,8,16,24,32,40,48,56,64,72,80,96,112,128):
  for k in range(1,4):results.append(run(c,f'c{c}-r{k}',16 if c==1 else max(32,c*2)))
 (r/'extended-done.json').write_text(json.dumps(results,indent=2))
 import refine
 for _ in range(7200):
  if (r/'finish').exists():break
  time.sleep(1)
