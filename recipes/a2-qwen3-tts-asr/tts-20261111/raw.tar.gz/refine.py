from sweep import run
from pathlib import Path
import json,time
r=Path('/bench/boundary128-20261111')
while not (r/'extended-done.json').exists():time.sleep(2)
def records():
 d={}
 for x in map(json.loads,(r/'progress.jsonl').read_text().splitlines()):
  if x['tag'].startswith('c'):d.setdefault(x['c'],[]).append(x)
 return d
def measure(c):
 if c in records():return
 for k in range(1,4):run(c,f'c{c}-r{k}',max(32,c*2))
measure(5)
bounds={}
for metric,threshold in [('ttfa_p95_ms',500),('rtf_p95',.8),('rtf_p95',1)]:
 d=records();passes=[c for c,v in d.items() if all(x[metric]<=threshold if metric=='ttfa_p95_ms' else x[metric]<threshold for x in v)]
 lo=max(passes);fails=[c for c,v in d.items() if c>lo and not all(x[metric]<=threshold if metric=='ttfa_p95_ms' else x[metric]<threshold for x in v)]
 if not fails:bounds[f'{metric}:{threshold}']={'pass':lo,'fail':None,'limited_to_128':True};continue
 hi=min(fails)
 while hi-lo>1:
  mid=(lo+hi)//2;measure(mid);v=records()[mid]
  if all(x[metric]<=threshold if metric=='ttfa_p95_ms' else x[metric]<threshold for x in v):lo=mid
  else:hi=mid
 bounds[f'{metric}:{threshold}']={'pass':lo,'fail':hi}
(r/'refined-done.json').write_text(json.dumps(bounds,indent=2))
