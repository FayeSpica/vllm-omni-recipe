import json,math,statistics,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
q=lambda x,p:sorted(x)[math.ceil(len(x)*p)-1]
out=[]
for c in sorted({json.loads(x)['c'] for x in (r/'progress.jsonl').read_text().splitlines() if json.loads(x)['tag'].startswith('c')}):
 rows=[];groups=[];rounds=[]
 for f in sorted(r.glob(f'c{c}-r*/summary.json')):
  d=json.loads(f.read_text());a=d['results'];rows+=a;groups+=d['groups']
  rounds.append({'run':f.parent.name,'n':len(a),'ttfa_p95_ms':q([x['ttfa_s']*1000 for x in a],.95),'rtf_p95':q([x['elapsed_s']/x['audio_s'] for x in a],.95),'zero_pass':sum(x['playback_clock']['0']['underruns']==0 for x in a)})
 n=len(rows)
 out.append({'c':c,'n':n,'ttfa_p50_ms':statistics.median(x['ttfa_s']*1000 for x in rows),'ttfa_p95_ms':q([x['ttfa_s']*1000 for x in rows],.95),'rtf_p95':q([x['elapsed_s']/x['audio_s'] for x in rows],.95),'audio_throughput':sum(x['audio_s'] for x in groups)/sum(x['elapsed_s'] for x in groups),'zero_pass':sum(x['playback_clock']['0']['underruns']==0 for x in rows),'buffer300_pass':sum(x['playback_clock']['300']['underruns']==0 for x in rows),'max_gap_ms':max(x['playback_clock']['0']['max_gap_s']*1000 for x in rows),'rounds':rounds})
(r/'aggregate.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
