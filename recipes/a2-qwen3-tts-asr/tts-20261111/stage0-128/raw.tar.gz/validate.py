from pathlib import Path
import json,hashlib,math
import numpy as np
r=Path(__file__).resolve().parent
manifest=json.loads((r/'source-manifest.json').read_text())
assert all(hashlib.sha256((r/k).read_bytes()).hexdigest()==v for k,v in manifest.items())
rows=[]
for d in sorted(r.glob('c*-r*')):
 if not d.is_dir():continue
 s=json.loads((d/'summary.json').read_text())
 for x in s['results']:
  assert x['status']==200 and not x['error'] and x['audio_s']>.5 and x['odd_bytes']==0,(d.name,x['id'])
 for f in d.glob('*.pcm'):
  a=np.frombuffer(f.read_bytes(),dtype='<i2').astype(np.float64);rms=float(np.sqrt(np.mean(a*a))/32768)
  assert rms>.0001,(f,rms)
  rows.append({'file':str(f.relative_to(r)),'bytes':f.stat().st_size,'rms':rms})
assert len(rows)==sum(len(json.loads(f.read_text())['results']) for f in r.glob('c*-r*/summary.json'))
out={'source_files':len(manifest),'valid_audio':len(rows),'minimum_rms':min(x['rms'] for x in rows),'maximum_audio_s':max(x['bytes']/48000 for x in rows),'failed':0}
out['audio_files_checked']=out.pop('valid_audio')
bad=[{'run':f.parent.name,'id':x['id'],'audio_s':x['audio_s']} for f in r.glob('c*-r*/summary.json') for x in json.loads(f.read_text())['results'] if not .5<x['audio_s']<40.8]
out['invalid_length_requests']=bad
out['failed']=len(bad)
out['valid_requests']=out['audio_files_checked']-len(bad)
(r/'validation.json').write_text(json.dumps(out,indent=2));print(out)
