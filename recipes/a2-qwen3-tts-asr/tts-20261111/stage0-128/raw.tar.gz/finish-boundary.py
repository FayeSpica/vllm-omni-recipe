from sweep import run
from pathlib import Path
import json,subprocess
r=Path('/bench/stage0-128-20261111')
fail=[]
for c,rounds in ((110,(2,3)),(109,(1,2,3)),(111,(1,2,3))):
 for k in rounds:
  try:run(c,f'c{c}-r{k}',c*2)
  except AssertionError:fail.append(f'c{c}-r{k}')
(r/'additional-invalid-rounds.json').write_text(json.dumps(fail))
subprocess.run(['python',str(r/'aggregate.py')],stdout=(r/'aggregate.log').open('w'),check=True)
(r/'measurement-done').touch()
