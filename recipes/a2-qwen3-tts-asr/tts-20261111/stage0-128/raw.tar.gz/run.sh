#!/bin/bash
set -euo pipefail
cd /bench
export ASCEND_RT_VISIBLE_DEVICES=0 VLLM_TARGET_DEVICE=npu HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export VLLM_DISABLE_COMPILE_CACHE=1
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:False
export XDG_CACHE_HOME=/bench/cache VLLM_CACHE_ROOT=/bench/cache/vllm TORCHINDUCTOR_CACHE_DIR=/bench/cache/inductor TRITON_CACHE_DIR=/bench/cache/triton
r=/bench/stage0-128-20261111
grep -q "cudagraph_mode: PIECEWISE" "$r/deploy.yaml"
grep -q "code_predictor_frame_graph: true" "$r/deploy.yaml"
grep -q "code_predictor_kv_cache: true" "$r/deploy.yaml"
grep -q "npu_fused_snake: false" "$r/deploy.yaml"
grep -q "codec_chunk_frames: 8" "$r/deploy.yaml"
grep -q "decode_batch_max_size: 8" "$r/deploy.yaml"

sed "s/event\['finish_reason'\]/event.get('finish_reason', 'stop')/g" /bench/trace/client.py >"$r/client.py"
export BENCH_STAGE_PATH="$r"
pid=
cleanup() {
 if [[ -n "$pid" ]]; then kill -TERM -- "-$pid" 2>/dev/null || true; wait "$pid" || true; fi
}
trap cleanup EXIT
for arm in omni; do
 if [[ "$arm" == omni ]]; then
  port=18364
  model=/root/.cache/huggingface/hub/models--Qwen--Qwen3-TTS-12Hz-1.7B-CustomVoice/snapshots/0c0e3051f131929182e2c023b9537f8b1c68adfe
  PYTHONPATH="$r${PYTHONPATH:+:$PYTHONPATH}" setsid vllm serve "$model" --served-model-name Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice --omni --api-server-count 4 --trust-remote-code --deploy-config /bench/stage0-128-20261111/deploy.yaml --host 127.0.0.1 --port "$port" >"$r/omni-server.log" 2>&1 &
 else
  port=18362
  XDG_CACHE_HOME=/bench/rsi-cache TRITON_CACHE_DIR=/bench/rsi-cache/triton OMP_NUM_THREADS=4 PYTHONPATH="$r/traced:$r${PYTHONPATH:+:$PYTHONPATH}" setsid /bench/rsi-venv/bin/python - >"$r/rsi-server.log" 2>&1 <<'PY' &
import json,runpy,sys
if "" in sys.path:sys.path.remove("")
cmd=json.load(open('rsi-effective-command.json'))
sys.modules["kernels"]=None
sys.argv=cmd[2:]
sys.argv[sys.argv.index('--port')+1]='18362'
runpy.run_module(cmd[2],run_name='__main__')
PY
 fi
 pid=$!
 for i in $(seq 1 600); do
  kill -0 "$pid"
  if curl --max-time 2 -fsS "http://127.0.0.1:$port/health" >/dev/null 2>&1; then break; fi
  sleep 2
 done
 /bench/rsi-venv/bin/python "$r/sweep.py" >"$r/sweep.log" 2>&1
 cleanup
 pid=
done
echo DONE
