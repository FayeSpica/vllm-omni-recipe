"""Measure live PCM arrivals and playback-clock underruns, without an audio device."""
import argparse
import asyncio
import base64
import json
import time
from pathlib import Path
import aiohttp

async def main(args):
    root = Path(args.out)
    root.mkdir(parents=True, exist_ok=True)
    case = json.loads(Path(args.case).read_text())
    payload = {k: v for k, v in case.items() if k not in ('id', 'han_characters')}
    payload.update(response_format='pcm', stream=True, stream_format='audio')
    (root/'request.json').write_text(json.dumps({**payload, 'engine':args.engine}, ensure_ascii=False, indent=2))
    async def audio_chunks(response):
        if args.engine == 'omni':
            async for chunk in response.content.iter_any():
                yield chunk
            return
        finished = False
        async for line in response.content:
            if not line.startswith(b'data: '):
                continue
            item = line[6:].strip()
            if item == b'[DONE]':
                break
            event = json.loads(item)
            if event.get('type') == 'speech.audio.delta':
                assert event['sample_rate'] == 24000 and event['channels'] == 1
                if event['audio']:
                    yield base64.b64decode(event['audio'],validate=True)
            elif event.get('type') == 'speech.audio.done':
                assert event.get('finish_reason', 'stop') == 'stop',event
                finished = True
        assert finished,'RSI did not emit speech.audio.done'
    if args.engine == 'rsi':
        payload.update(stream_format='sse')
    active = 0
    max_active = 0
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=240)) as session:
        async def request(label):
            texts = (
                "今天阳光明媚，我们一起去公园里散步，听听树上的鸟儿唱歌，享受这段轻松美好的时光。",
                "请把蓝色文件夹放到会议室靠窗的桌上，下午三点我们会一起核对里面的资料。",
                "清晨的渡船经过安静的河湾，船上的旅客望着远处的群山，慢慢喝完一杯热茶。",
                "如果明天上午下雨，我们就改乘地铁去图书馆，先还两本书，再去楼下吃午饭。",
            )
            index = int(label.rsplit("_", 1)[-1])
            request_payload = dict(payload, input=texts[index % 4], voice=("Vivian", "Serena")[(index // 4) % 2])
            (root / f"{label}.input.json").write_text(json.dumps(request_payload, ensure_ascii=False))

            nonlocal active, max_active
            active += 1
            max_active = max(max_active, active)
            start_ns = time.monotonic_ns()
            start = start_ns/1e9
            events = []
            states = {ms: {'end': None, 'gaps': []} for ms in [0,100,300,500]}
            total = 0
            error = None
            status = None
            try:
                async with session.post(args.url+'/v1/audio/speech', json=request_payload, headers={'X-Request-Id':root.name+':'+label}) as resp:
                    status = resp.status
                    if status != 200:
                        raise RuntimeError((await resp.text())[:2000])
                    with (root/(label+'.pcm')).open('wb') as audio, (root/(label+'.arrival.jsonl')).open('w') as log:
                        async for chunk in audio_chunks(resp):
                            now = time.monotonic()-start
                            old_samples = total//2
                            total += len(chunk)
                            duration = (total//2-old_samples)/24000
                            event = {'t':now, 'bytes':len(chunk), 'audio_s':duration}
                            for ms, st in states.items():
                                if st['end'] is None:
                                    st['end'] = now+ms/1000
                                gap = max(0,now-st['end'])
                                if gap > 0:
                                    st['gaps'].append({'t':now,'seconds':gap})
                                st['end'] = max(st['end'],now)+duration
                                event['buffer_ms_'+str(ms)] = (st['end']-now)*1000
                            events.append(event)
                            log.write(json.dumps(event)+'\n'); log.flush()
                            audio.write(chunk)
            except Exception as exc:
                error = repr(exc)
            finally:
                active -= 1
            result = dict(id=label,start_ns=start_ns,status=status,error=error,elapsed_s=time.monotonic()-start,ttfa_s=events[0]['t'] if events else None,reads=len(events),audio_s=total/48000,odd_bytes=total%2,playback_clock={str(ms):{'underruns':len(st['gaps']),'total_gap_s':sum(g['seconds'] for g in st['gaps']),'max_gap_s':max((g['seconds'] for g in st['gaps']),default=0),'gaps':st['gaps']} for ms,st in states.items()})
            (root/(label+'.json')).write_text(json.dumps(result,indent=2))
            print(json.dumps(result),flush=True)
            return result
        for i in range(args.warmup):
            r=await request('warmup_'+str(i))
            if r['error']: raise RuntimeError('warmup failed')
        all_results=[]
        request_counts = args.requests_per_concurrency or [args.requests] * len(args.concurrency)
        if len(request_counts) != len(args.concurrency):
            raise ValueError("--requests-per-concurrency must match --concurrency")
        groups = []
        for c, request_count in zip(args.concurrency, request_counts):
            sem=asyncio.Semaphore(c)
            async def bounded(i):
                async with sem: return await request(f'c{c}_{i:03}')
            group_start = time.monotonic()
            results=await asyncio.gather(*(bounded(i) for i in range(request_count)))
            group_elapsed = time.monotonic() - group_start
            all_results.extend(results)
            groups.append({
                'concurrency': c,
                'requests': request_count,
                'elapsed_s': group_elapsed,
                'audio_s': sum(r['audio_s'] for r in results),
                'audio_throughput': sum(r['audio_s'] for r in results) / group_elapsed,
                'request_throughput': len(results) / group_elapsed,
            })
            if any(r['error'] for r in results): break
        (root/'summary.json').write_text(json.dumps({'max_active':max_active,'groups':groups,'results':all_results},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--engine',choices=['omni','rsi'],default='omni'); p.add_argument('--case',required=True); p.add_argument('--out',required=True); p.add_argument('--url',default='http://127.0.0.1:8091'); p.add_argument('--concurrency',type=int,nargs='+',default=[1,2,4,8]); p.add_argument('--requests',type=int,default=48); p.add_argument('--requests-per-concurrency',type=int,nargs='+'); p.add_argument('--warmup',type=int,default=2)
    asyncio.run(main(p.parse_args()))